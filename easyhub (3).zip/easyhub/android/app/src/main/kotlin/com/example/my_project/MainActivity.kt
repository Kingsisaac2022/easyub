package com.mycompany.easyhub

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
